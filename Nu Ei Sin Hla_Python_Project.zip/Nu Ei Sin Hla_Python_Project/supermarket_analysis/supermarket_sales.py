'''Section-A'''
'''Loading dataset'''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("supermarket_analysis/supermarket_sales.csv")

'''Show first row'''
print(df.head())

'''Basic information'''
print(df.info())

'''Missing values'''
print(df.isnull().sum())


'''Python basic function'''
def show_summary(data):
    print("\n=== Summary ===")
    print("Total Records:", len(data))
    print("Total Revenue:", data["Total_Sales"].sum())
    print("Total Quantity Sold:", data["Quantity"].sum())
show_summary(df)



'''Section-B'''
'''Convert pandas to numpy format'''
sales_array = df["Total_Sales"].to_numpy()
qty_array = df["Quantity"].to_numpy()


print("Average Sales:", np.mean(sales_array))
print("Maximum Sale:", np.max(sales_array))
print("Minimum Sale:", np.min(sales_array))
print("Average Quantity:", np.mean(qty_array))


'''Section-C'''
category_sales = df.groupby("Category")["Total_Sales"].sum()
region_sales = df.groupby("Region")["Total_Sales"].sum()
print(category_sales)
print(region_sales)

df["Date"] = pd.to_datetime(df["Date"])
df["Month"] = df["Date"].dt.month_name()
monthly_sales = df.groupby("Month")["Total_Sales"].sum()
print(monthly_sales)


'''Section-D'''

best_category = category_sales.idxmax()
best_category_value = category_sales.max()

best_region = region_sales.idxmax()
best_region_value = region_sales.max()

category_sales.plot(kind="bar")
plt.title("Total Sales by Product Category")
plt.xlabel("Category")
plt.ylabel("Sales")
# plt.bar(category_sales.index, category_sales.values)
# plt.title("Total Sales by Product Category")
plt.show()


region_sales.plot(kind="pie", autopct="%1.1f%%")
plt.title("Sales Contribution by Region")
plt.ylabel("")
plt.show()

monthly_sales.plot(kind="line", marker="o")
plt.title("Monthly Sales Trend")
plt.xlabel("Month")
plt.ylabel("Sales")
plt.show()

df["Total_Sales"].plot(kind="hist", bins=10)
plt.title("Sales Distribution")
plt.xlabel("Total Sales")
plt.show()