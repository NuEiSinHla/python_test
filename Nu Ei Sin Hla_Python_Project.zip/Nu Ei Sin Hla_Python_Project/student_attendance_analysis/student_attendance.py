import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

# Step 2 — Read Excel File (safe path method)
current_folder = os.path.dirname(__file__)
file_path = os.path.join(current_folder, "student_attendance.xlsx")

df = pd.read_excel(file_path)
print(df.head())
print(df.info())
print(df.isnull().sum())

'''Caculate attendance percentage'''
df["Attendance_%"] = (df["Attended"] / df["Total_Classes"]) * 100
print(df.head())


'''Convert pandas to numpy format'''
attendance_array = df["Attendance_%"].to_numpy()
print("Average Attendance Percentage:", np.mean(attendance_array))
print("Highest Attendance Percentage:", np.max(attendance_array))
print("Lowest Attendance Percentage:", np.min(attendance_array))


'''Attendance below 75%'''
low_attendance_students = df[df["Attendance_%"] < 75]
print(low_attendance_students[["Student_ID", "Name", "Attendance_%"]])


'''Best attendance student'''
best_student = df.loc[df["Attendance_%"].idxmax()]
print(best_student[["Student_ID", "Name", "Attendance_%"]])


'''Bar Chart'''
plt.figure()
plt.bar(df["Name"], df["Attendance_%"])
plt.title("Student Attendance Percentage")
plt.xlabel("Student Name")
plt.ylabel("Attendance %")
plt.xticks(rotation=60)
plt.tight_layout()
plt.show()


'''Pie Chart'''
good_count = (df["Attendance_%"] >= 75).sum()
low_count = (df["Attendance_%"] < 75).sum()

labels = ["Good Attendance", "Low Attendance"]
values = [good_count, low_count]

plt.figure()
plt.pie(values, labels=labels, autopct="%1.1f%%")
plt.title("Attendance Performance")
plt.show()

'''Histogram'''
plt.figure()
plt.hist(df["Attendance_%"], bins=8)
plt.title("Distribution of Attendance Percentage")
plt.xlabel("Attendance %")
plt.ylabel("Number of Students")
plt.show()

'''Output'''
output_path = os.path.join(current_folder, "student_attendance_analysis_report_output.xlsx")

df.to_excel(output_path, index=False)

print("\nAttendance report exported successfully!")
print("Saved File:", output_path)